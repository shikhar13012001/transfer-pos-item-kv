# Validation contract

## Baseline and candidate identity

Tie each report to commit SHA (or base SHA plus patch digest), module/configuration,
command, environment, timestamp, and artifact digest where available. Use identical
profiles, JDK and repository policy for base/candidate comparisons. Inspect fresh
CI reports only after confirming that identity. Do not count missing/skipped checks
as success or assume a previous branch's green build validates the current candidate.

## Required evidence layers

1. Resolve covered graphs and artifacts; inspect unresolved components, selection
   reasons, platform/constraint deviations, and compile/runtime differences.
2. Diff components AND coverage. Use existing machine-readable graph/SBOM tooling.
   Supplemental native lock diffs cannot establish parent paths or shaded contents.
3. Scan covered dependencies and the final JAR/container with approved tools.
   Verify the target advisory and assess introduced findings; do not ignore another
   copy/configuration or confuse a default-branch scan with the candidate artifact.
4. Run compile/unit/generator checks and targeted integration tests by family.
5. Build/start the deployable artifact under a representative runtime. Resolve-only
   success cannot establish binary linkage, service-provider or native compatibility.
6. Retain repository-mandated checks and a lightweight final environment smoke.

## Test profiles to tailor, not invented task names

| Change | Required behavior to cover |
|---|---|
| gRPC/Netty/TLS | Real socket calls, TLS/mTLS when used, deadline/cancel, reconnect, native loading |
| Serialization | Golden payloads, null/default fields, Kotlin classes, enums, compatible wire contracts |
| Database driver/pool | Auth/connect, transaction commit/rollback, timeout/reconnect, representative query |
| Logging/telemetry | Startup/provider binding, emitted log/metric/trace |
| Build/plugin/generator | Clean relevant build, generated code, packaged output, wrapper/JDK compatibility |
| Test-only | Relevant tests and evidence that production graph/package did not change |

Discover actual task names; never claim `integrationTest` exists without checking.
Use existing approved fixtures/Testcontainers where available. Do not install
Docker or fetch an unapproved fixture image simply to make tests runnable.
Document environment-only behavior (certificates, proxies, mesh, native runtime)
that cannot be reproduced locally. Avoid repeated full clean builds unless mandated;
run the relevant clean/package check at the final validated candidate.

## Risk and merge policy

Evaluate the entire resolved change, overrides, native/classifier changes, runtime
sensitivity, and test evidence. A semantic patch label alone is insufficient.

- Candidate for auto-merge: team-allowlisted family, expected scoped diff, no new
  override/trust/policy changes, complete required CI, current merge-candidate evidence.
- Batchable: routine changes with a shared compatibility boundary and validation suite.
- Manual: transport/TLS/auth, serialization, drivers/native code, broad BOM changes,
  compiler/toolchain/generator updates, temporary overrides, or incomplete support evidence.

This skill recommends classification only. Required CI, permissions, code owners,
branch protections, and merge policy implement enforcement outside the prompt.
Retest the combined merge candidate; individually green PRs are not combined evidence.

## Expensive environment gate and closure

Prefer one validated candidate per compatible batch. Final smoke: readiness,
authenticated request, representative operation, critical outbound connection.
For sensitive changes, retain environment-specific integration checks. Promote the
same immutable artifact. Let the approved rollout system handle canary, monitoring,
abort thresholds and rollback. Missing traffic/metrics is not a successful canary.

The agent must not deploy, publish or close alerts in this workflow. Report merged,
scanner-refreshed, deployed and deployment-validated as distinct observed states.
An exception requires owner/expiry/review; it is not a fix.
