# Primary references

Reviewed for this starter on 2026-09-09. Check the installed Gradle/Kotlin/Copilot
versions before adopting syntax; current documentation is not a reason to upgrade.

## Copilot structure and permissions
- https://docs.github.com/en/copilot/how-tos/copilot-on-github/customize-copilot/customize-cloud-agent/add-skills
- https://docs.github.com/en/copilot/reference/custom-agents-configuration
- https://code.visualstudio.com/docs/agent-customization/custom-agents
- https://code.visualstudio.com/docs/agent-customization/agent-skills

## Gradle/JVM
- https://docs.gradle.org/current/userguide/viewing_debugging_dependencies.html
- https://docs.gradle.org/current/userguide/centralizing_catalog_platform.html
- https://docs.gradle.org/current/userguide/dependency_constraints.html
- https://docs.gradle.org/current/userguide/dependency_locking.html
- https://docs.gradle.org/current/userguide/dependency_verification.html
- https://docs.gradle.org/current/userguide/compatibility.html
- https://kotlinlang.org/docs/gradle-configure-project.html
- https://github.com/grpc/grpc-java/blob/master/SECURITY.md
- https://protobuf.dev/support/cross-version-runtime-guarantee/

## Maven fallback
- https://maven.apache.org/guides/introduction/introduction-to-dependency-mechanism.html
- https://maven.apache.org/plugins/maven-help-plugin/effective-pom-mojo.html

## Implementation examples, not install requirements
- https://github.com/github/awesome-copilot
- https://github.com/gradle/github-dependency-submission-demo
- https://github.com/gradle/actions/blob/main/docs/dependency-submission.md
- https://github.com/autonomousapps/dependency-analysis-gradle-plugin

Review third-party skills, plugins, wrappers and scripts before use. Do not publish
internal Build Scans or dependency inventories just because a demo does so.
