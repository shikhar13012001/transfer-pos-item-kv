# Enterprise dependency dashboard intake

Use this reference when the user supplies a list copied or exported from an enterprise
security/dependency dashboard such as Dot Connector. The dashboard is a finding source,
not the repository dependency-resolution authority.

## Accepted input forms

Accept free-form lines, Markdown tables, CSV-like text, JSON, ticket exports, or a
transcription of a dashboard screenshot. Do not require every field to be present.
Preserve unknown values as unknown.

Useful input fields are:

| Field | Meaning |
|---|---|
| package | Maven coordinate or package name, preferably `group:artifact` |
| detectedVersion | Version reported by the dashboard |
| advisory | CVE, GHSA, vendor finding, or dashboard issue ID |
| severity | Dashboard-reported severity |
| recommendedVersion | Dashboard suggestion; candidate only, never automatic target |
| repository/module | Repository or module named by the source |
| scanRevision | Commit/tag/build identifier, when available |
| artifactDigest | Container/JAR/image digest, when available |
| scanTime | Time of the source observation |
| notes | Dashboard reasoning or source metadata |

## Normalization contract

Create one normalized record per finding and retain the raw row. Use this logical
shape; it is an output convention, not a required input format:

```yaml
source: enterprise-dashboard
raw: "original row or object"
package: io.netty:netty-codec-http2
ecosystem: maven
detectedVersion: 4.x.y
advisory: CVE-...
severity: HIGH
recommendedVersion: 4.x.z
dashboardCandidateOnly: true
repository: unknown
module: unknown
scanRevision: unknown
artifactDigest: unknown
scanTime: unknown
initialStatus: NEEDS_GRAPH_CONFIRMATION
```

Do not infer the current repository revision from the scan time. Do not infer direct
vs transitive from whether the package appears in a version catalog. Do not infer
production scope from severity.

## Reconciliation rules

For each row, answer these questions from repository/approved evidence:

1. Does this exact component/version exist in the current resolved graph or packaged artifact?
2. Which projects/configurations contain it?
3. Is it direct, transitive, build tooling, plugin classpath, shaded, or image/OS content?
4. What paths introduce it?
5. Why did Gradle select this version?
6. What declaration/platform/BOM/constraint/plugin actually owns the version?
7. Does the source report match the current revision/artifact identity?
8. Is the dashboard-recommended target available, organization-approved, actually
   remediating, and compatible? Evaluate all four independently.
9. Is another supported target preferable to the dashboard recommendation?
10. What validation proves the candidate works for every introducing stack?

## Required distrust-but-verify behavior

Never perform these shortcuts:

- `dashboard says X -> change declaration to X`;
- `fixedVersion exists -> force it globally`;
- `transitive -> add direct implementation dependency`;
- `not in build.gradle.kts -> false positive`;
- `test scope -> dismiss`;
- `artifact exists in Artifactory -> organization approved`;
- `Gradle resolves -> runtime compatible`;
- `external Netty upgraded -> grpc-netty-shaded fixed`;
- `one configuration is clean -> repository is clean`.

A dashboard recommendation can be rejected or replaced when independent evidence shows
that the version owner, compatibility boundary, supported maintenance line, shaded
packaging, or current repository state requires a different remediation.

## Large-list handling

Triage the whole list first. Then group only findings sharing a compatibility boundary
or version owner. Keep unrelated updates in separate plans so failures can be attributed
and rollback remains practical.

Recommended output columns:

| Source item | Current repo status | Scope | Origin/paths | Version owner | Proposed action | Target set | Evidence gap | Plan/batch |
|---|---|---|---|---|---|---|---|---|

Every source item must end with a disposition, including rows intentionally not changed.
