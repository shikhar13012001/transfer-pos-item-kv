# Maven fallback for Java/Kotlin JVM repositories

Use only when the repository actually uses Maven. Keep the same approval,
evidence, scope and validation gates; do not paste Gradle resolution rules into Maven.

Read wrapper settings, parent POMs, imported BOMs, active profiles, properties,
`dependencyManagement`, `pluginManagement`, plugin dependencies and repository mirrors.
Use the approved pinned plugin versions/tooling already present in the repository.
After execution approval, typical diagnostic goals are:

```bash
./mvnw -version
./mvnw help:active-profiles
./mvnw help:effective-pom -Dverbose
./mvnw dependency:tree -Dverbose
```

Scope these to affected modules and the same profiles/settings as the build.
Do not publish effective settings, credentials, or private repository tokens.
Do not silently download newer diagnostic plugins outside policy.

Maven dependency mediation differs from Gradle; dependencyManagement can control
transitive application versions, but it does not generally manage dependencies
inside build plugins. Upgrade the owning parent/BOM/library/plugin in the correct
scope. Inspect effective POM origin and the full selected tree.

Use repository-approved dependency tree/SBOM diffs. The bundled Gradle lock helper
is inapplicable and must not be treated as a Maven lock mechanism. Run existing
Enforcer rules rather than introducing a new convergence regime in a small fix.
Discover exact Kotlin compiler/code-generation, test, packaging, scan and startup
commands. Compare base and candidate under identical active profiles/settings.
