# Gradle and Java/Kotlin guidance

## Discover before executing

Read `settings.gradle[.kts]`, relevant `build.gradle[.kts]`, wrapper properties,
`gradle.properties` without exposing secrets, version catalogs, convention plugins,
`buildSrc`, included builds, platform modules, plugin-management and repository
rules. Do not assume every repository uses `libs.versions.toml` or Spring Boot.
Identify toolchain JDK, daemon JDK, test JDK, JVM bytecode targets, deployment JDK,
Kotlin Gradle plugin, compiler plugins (KSP/kapt/serialization), and generators.
Check the actual release's Gradle/Kotlin/JDK compatibility, not today's defaults.
Do not infer that embedded Kotlin in Gradle equals the application's Kotlin plugin.

## Collect diagnostic evidence

The following are templates. Replace `:service` and the coordinate with discovered
values; use `./gradlew.bat` in Windows PowerShell. Do not execute placeholders.
Respect execution approval and use the repository wrapper, not an arbitrary global Gradle.

```bash
./gradlew --version
./gradlew projects
./gradlew :service:dependencies --configuration runtimeClasspath
./gradlew :service:dependencyInsight --configuration runtimeClasspath --dependency io.netty:netty-handler
./gradlew :service:dependencyInsight --configuration compileClasspath --dependency io.netty:netty-handler
./gradlew :service:buildEnvironment
```

Do not use `--single-path` during initial investigation. Include custom integration
tests, test fixtures, annotation processors, kapt/KSP, code generation, and included
builds where relevant. Plugin classpaths require separate inspection; one
`buildEnvironment` report is not proof of complete included-build coverage.
Dependency reports can display unresolved edges: require actual artifact resolution
and build/test evidence, not just a task's successful report generation.

## Change ownership

| Owner | Preferred edit |
|---|---|
| Independent direct version | Existing declaration/catalog/property |
| BOM/platform/framework | Supported owner maintenance update |
| Transitive parent | Parent update, inspecting all other introducing parents |
| Convention plugin/internal platform | Update owning component or request platform-owner change |
| Plugin/build tooling | Plugin version/build classpath, not application scope |
| Lock pin | Update deliberately as part of the approved candidate, not delete locks |

Catalogs are declarations, not global pins. Ordinary platforms add constraints;
`enforcedPlatform` forces selections and has consumer implications for published
libraries. `strictly`, `force`, exclusions and substitutions need explicit rationale.
Do not apply Maven's nearest-wins model to Gradle. Competing requested versions
are not by themselves proof of incompatibility; selected versions and contracts matter.
Do not blanket-enable `failOnVersionConflict` in a mature build during remediation.

A narrow constraint can express a reviewed transitive requirement without adding
an unused direct dependency. Match the appropriate declarable configuration and
use `because` with the issue/exception reference. Verify the selected result:
a non-strict requirement does not force an exact final version. For published
libraries, review what constraints/metadata propagate to consumers as well.

## Coupled families

### gRPC, Netty, TLS and Protobuf

Record framework/internal BOM, gRPC Java family, grpc-kotlin when present,
transport choice, Netty core, tcnative/TLS provider, Protobuf runtime/generator,
JDK, OS and architecture. Inspect released BOM/POM/module metadata.
A gRPC Java BOM is not proof that every separately versioned Kotlin integration
or Protobuf generator is aligned. Do not force every `io.netty:*` artifact to one
version: core Netty and tcnative use distinct version lines.

A `grpc-netty-shaded` finding must be traced to the bundled/relocated copy. Changing
ordinary external Netty dependencies does not replace that copy. A transport
switch is an architecture change needing explicit approval. With unshaded Netty,
check every other stack sharing it (for example Reactor Netty).

Use release-specific upstream compatibility guidance, but also current advisory
and organization approval evidence. A known-working matrix is not a security scan.
Validate generated Protobuf code against its runtime: newer generated code with
an older runtime is unsupported. Use a real socket/TLS test, not only in-process RPC.

### Kotlin and serialization

Check Kotlin Gradle plugin/Gradle/JDK support and Java/Kotlin JVM target agreement.
Compiler plugins and annotation/code-generation processors are tooling, but affect
produced code. Do not require all Kotlin-related projects (such as coroutines) to
share the compiler version. Follow each family's release compatibility guidance.
Test Kotlin null/default behavior, enums and golden payloads for serialization changes.

## Locks and verification

Resolve the affected configurations while regenerating their locks. A command like
`./gradlew :service:dependencies --update-locks 'io.grpc:*,io.netty:*'` is appropriate
only for that approved family change and does not establish coverage of all builds.
Inspect added/removed configurations and all extra selected modules. Do not manually
edit lock state. Do not add locking or a new management framework in the fix PR.

Checksums/signatures establish artifact identity/trust, not absence of vulnerabilities.
Bootstrapping verification metadata trusts the retrieved bytes; require provenance
review before adding hashes/keys. Keep existing verification strictness intact.

Use the lock comparison helper only when native modern Gradle lockfiles exist.
Custom lock locations need explicit `--pattern`; legacy per-configuration formats
are rejected. A lock diff is a supplemental version/configuration report, not a
resolved edge/variant graph, reachability analysis, or complete security gate.
