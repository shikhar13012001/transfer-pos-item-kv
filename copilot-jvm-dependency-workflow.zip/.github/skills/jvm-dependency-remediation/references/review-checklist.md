# Reviewer contract

Read the original dashboard/list evidence, approved plan, base/candidate diff, policy,
and test/scan reports. Do not trust the remediator's summary without checking support.
Do not edit. If fresh reports are unavailable, report BLOCKED_VALIDATION rather than
request permissions that turn this read-only reviewer into another implementation agent.

Check:
1. Every input dashboard row has a disposition and preserved source evidence.
2. Dashboard-reported version is reconciled with the current revision/artifact; stale
   scan, already-fixed, absent, shaded, build-tooling and image cases are not conflated.
3. Correct coordinate, advisory aliases, all paths/scopes, and artifact identity.
4. Version owner and exact approved target set; internal availability is not approval.
5. Dashboard suggested/fixed version was independently accepted or rejected with reason.
6. Supporting release compatibility, coupled families, generated-code/runtime pairs,
   and shaded/embedded copies were considered where relevant.
7. Expected full graph delta, preserved coverage, and no unrelated dependency changes.
8. No test-to-runtime scope leakage or plugin fix applied to application scope.
9. Reviewed trust metadata; no weakened security, CI, repository, TLS, or scan controls.
10. Exact validation commands/results/revisions and justified not-applicable checks.
11. Baseline evidence for any claim that a failure was pre-existing.
12. Temporary overrides have an owner, removal condition, and expiry.
13. PR body distinguishes validated patch, merge, scanner refresh, and deployment.

Return: recommendation (READY_FOR_HUMAN_REVIEW / CHANGES_REQUIRED /
BLOCKED_VALIDATION), blocking findings with file/evidence references, risk class,
unverified claims, and the single next required decision. This is advisory review,
not an independent organization/security approval or permission to merge.
