# Dependency remediation plan

Plan ID:
Input source/export:
Requested findings/modules:
Base commit and current checkout:
Dashboard scan revision/artifact identity:
Workspace/local edits:
Policy source/version and approver:
Environment (daemon/toolchain/test/deployment JDK, Gradle, Kotlin, OS/architecture):

## Dashboard reconciliation

| Source finding | Reported version | Suggested version | Current repo status | Scope/configuration | Direct/transitive paths | Version owner | Presence/artifact evidence |
|---|---|---|---|---|---|---|---|

Disposition values: CONFIRMED_ACTIONABLE / ALREADY_FIXED_IN_CURRENT_REVISION /
STALE_OR_REVISION_MISMATCH / ABSENT_FROM_COVERED_ARTIFACTS /
TRANSITIVE_OWNER_UPDATE_REQUIRED / BUILD_TOOLING_REMEDIATION /
SHADED_OR_PACKAGED_COPY_REVIEW / OS_OR_BASE_IMAGE_REMEDIATION / BLOCKED_EVIDENCE.

## Candidate decision

| Candidate | Exact version set | Available internally | Organization approved | Security evidence | Compatibility evidence | Dashboard recommendation accepted/rejected and why | Expected graph impact |
|---|---|---|---|---|---|---|---|

Chosen candidate and why:
Alternatives considered / evaluation budget used:
Related findings covered by this compatibility boundary:
Related findings intentionally excluded / next plan:

## Edit and validation contract

Allowed files/components:
Protected files and prohibited changes:
Approved branch/base strategy:
Configuration/build coverage:
Baseline evidence or missing baseline:
Exact diagnostic/test/package/scan/regeneration commands:
Required family-specific behavior:
Existing approved artifact repositories and fixture images:
Graph delta expected and escalation threshold:
Override owner/removal condition/expiry (when applicable):
Rollback/final environment gate:
Known blockers, unavailable sources and next owner action:
Risk classification and rationale:

## Decision

State: PLAN_READY / BLOCKED_APPROVAL / BLOCKED_EVIDENCE
Approval: not yet granted

User approval must identify this plan/candidate and permitted source changes.
Execution authorization for diagnostics does not approve a patch or publication.
