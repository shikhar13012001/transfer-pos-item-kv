# Dependency remediation evidence / PR body

## Outcome

Status: PLAN_READY / BLOCKED_APPROVAL / BLOCKED_VALIDATION / PATCH_VALIDATED
Plan ID and explicit approval reference:
Input dashboard/export and scan identity:
Base revision / candidate revision or patch digest:
Artifacts and digests:
Risk class and owner:

## Dashboard-to-repository reconciliation

| Source finding | Dashboard version | Dashboard suggestion | Current repo status | Actual scope/path | Version owner | Disposition |
|---|---|---|---|---|---|---|

Every source row must have a disposition. Preserve stale/already-fixed/absent findings
rather than silently dropping them.

## Remediated findings

| Advisory | Scope/path | Previous selected version | New selected version | Internal approval reference | Security/compatibility evidence | Outcome |
|---|---|---|---|---|---|---|

## Changes

Version owner changed:
Why target differs from dashboard suggestion, if applicable:
Full resolved changes (added/removed/changed) by configuration:
Lock coverage added/removed:
Unexpected or unrelated changes:
Verification metadata changes and provenance approval:
Override owner, expiry and removal condition:

## Validation

| Check | Exact command | Revision/artifact | Result | Exit code | Cache status | Timestamp/log path |
|---|---|---|---|---|---|---|

Use PASS / FAIL / NOT_RUN / BLOCKED / NOT_APPLICABLE (with rationale).
Do not infer results from a planned command or a different revision's logs.

## Remaining work

Unresolved dashboard findings and why:
Findings requiring another compatibility-boundary plan:
Missing evidence and responsible owner:
Environment-specific final smoke:
Rollback plan:
Required code owner/security review:

## Observed release state

Patch validated:
Merged:
Default-branch scanner refreshed:
Deployed artifact digest:
Deployment validated:

Unknown and not-performed states must remain explicit. Do not say fixed/deployed
when only source changes were made. Do not include credentials or sensitive logs.
