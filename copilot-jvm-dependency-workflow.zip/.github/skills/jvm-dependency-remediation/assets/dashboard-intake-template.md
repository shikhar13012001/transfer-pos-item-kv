# Dependency dashboard input template

Paste or export the dashboard list in any readable format. This template is optional.
The skill must not require fields the dashboard does not provide.

```text
Dashboard/source: [Dot Connector / enterprise SCA / other]
Repository: [optional]
Scan revision/build: [optional]
Scan time: [optional]

Dependencies/findings:
1. Package: [group:artifact]
   Detected version: [version]
   Advisory/finding: [CVE/GHSA/internal ID]
   Severity: [optional]
   Dashboard recommended/fixed version: [optional]
   Module/image: [optional]
   Notes: [optional]

2. Package: ...
```

The dashboard-recommended version is input evidence only. The workflow must independently
resolve the current repository graph, determine the version owner, and choose the target.
