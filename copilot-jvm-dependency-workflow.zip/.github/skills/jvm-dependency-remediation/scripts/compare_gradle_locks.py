#!/usr/bin/env python3
"""Compare modern Gradle lock state without running builds or contacting a network.

This is a supplemental inventory report, NOT a vulnerability/compatibility gate.
Python 3.10+; standard library only. Input files are never modified.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import sys
from typing import Any

IGNORED_DIRS = {'.git', '.gradle', '.kotlin', 'node_modules', '__pycache__', '.venv'}
DEFAULT_NAMES = {'gradle.lockfile', 'buildscript-gradle.lockfile'}
LIMITATIONS = [
    'Only discovered modern native Gradle lockfiles are covered; custom paths require --pattern.',
    'Locks do not establish current resolution, introducing paths, unlocked scopes, variants or classifiers.',
    'This report does not inspect shaded contents, verify artifacts, scan vulnerabilities or test compatibility.',
    'Exit 0 means comparison completed, not that an update is safe or that required coverage is complete.'
]


class InputError(ValueError):
    """Invalid or unsupported evidence; never interpret as a clean comparison."""


@dataclass
class LockState:
    records: dict[tuple[str, str], str]
    configurations: set[str]
    sha256: str


def parse_lock(text: str, label: str = '<input>') -> LockState:
    records: dict[tuple[str, str], str] = {}
    configurations: set[str] = set()
    empty_configurations: set[str] = set()
    saw_data = False
    saw_empty = False
    for number, original in enumerate(text.splitlines(), 1):
        line = original.strip()
        if not line or line.startswith('#'):
            continue
        saw_data = True
        coordinate, separator, raw_configs = line.partition('=')
        if not separator:
            raise InputError(f'{label}:{number}: expected modern coordinate=configurations format')
        names = raw_configs.split(',') if raw_configs else []
        if any(not n or n != n.strip() or '=' in n or any(c.isspace() for c in n) for n in names):
            raise InputError(f'{label}:{number}: invalid configuration name')
        if len(names) != len(set(names)):
            raise InputError(f'{label}:{number}: repeated configuration name')
        if coordinate == 'empty':
            if saw_empty:
                raise InputError(f'{label}:{number}: repeated empty marker')
            saw_empty = True
            empty_configurations.update(names)
            configurations.update(names)
            continue
        parts = coordinate.split(':')
        if len(parts) != 3 or any(not p or any(c.isspace() for c in p) for p in parts):
            raise InputError(f'{label}:{number}: expected group:artifact:version')
        if not names:
            raise InputError(f'{label}:{number}: component has no configurations')
        module = ':'.join(parts[:2])
        version = parts[2]
        for configuration in names:
            key = (configuration, module)
            if key in records:
                raise InputError(f'{label}:{number}: duplicate/conflicting {module} in {configuration}')
            records[key] = version
            configurations.add(configuration)
    if not saw_data:
        raise InputError(f'{label}: empty or comments-only file is not valid lock evidence')
    populated = {configuration for configuration, _ in records}
    overlap = populated & empty_configurations
    if overlap:
        raise InputError(f'{label}: configurations marked both empty and populated: {sorted(overlap)}')
    return LockState(records, configurations, hashlib.sha256(text.encode('utf-8')).hexdigest())


def matches(relative: str, patterns: list[str]) -> bool:
    path = PurePosixPath(relative)
    return path.name in DEFAULT_NAMES or any(
        path.match(pattern) or (pattern.startswith('**/') and path.match(pattern[3:]))
        for pattern in patterns
    )


def load_snapshot(root: Path, patterns: list[str]) -> tuple[dict[str, LockState], list[str]]:
    root = root.resolve()
    if not root.is_dir():
        raise InputError(f'Not a directory: {root}')
    states: dict[str, LockState] = {}
    skipped_symlinks: list[str] = []
    def walk_error(error: OSError) -> None:
        raise error
    for directory, dirs, files in os.walk(root, followlinks=False, onerror=walk_error):
        current = Path(directory)
        kept = []
        for dirname in sorted(dirs):
            child = current / dirname
            if dirname in IGNORED_DIRS:
                continue
            if child.is_symlink():
                skipped_symlinks.append(child.relative_to(root).as_posix())
            else:
                kept.append(dirname)
        dirs[:] = kept
        for filename in sorted(files):
            path = current / filename
            relative = path.relative_to(root).as_posix()
            if current.name == 'dependency-locks' and filename.endswith('.lockfile'):
                raise InputError(f'{relative}: legacy per-configuration layout is unsupported; use approved graph tooling')
            if not matches(relative, patterns):
                continue
            if path.is_symlink():
                raise InputError(f'{relative}: refusing a symlinked lockfile')
            raw = path.read_bytes()
            state = parse_lock(raw.decode('utf-8-sig'), relative)
            state.sha256 = hashlib.sha256(raw).hexdigest()
            states[relative] = state
    if not states:
        raise InputError(f'No modern Gradle lockfiles found in {root}; missing evidence is not a clean graph')
    return states, sorted(skipped_symlinks)


def compare(base: dict[str, LockState], head: dict[str, LockState]) -> dict[str, Any]:
    changes: list[dict[str, Any]] = []
    coverage: list[dict[str, Any]] = []
    for filename in sorted(base.keys() | head.keys()):
        before = base.get(filename)
        after = head.get(filename)
        old = before.records if before else {}
        new = after.records if after else {}
        for configuration, module in sorted(old.keys() | new.keys()):
            key = (configuration, module)
            if old.get(key) != new.get(key):
                kind = 'added' if key not in old else 'removed' if key not in new else 'version_changed'
                changes.append({
                    'lockfile': filename, 'configuration': configuration, 'module': module,
                    'before': old.get(key), 'after': new.get(key), 'kind': kind
                })
        old_configs = before.configurations if before else set()
        new_configs = after.configurations if after else set()
        if old_configs != new_configs:
            coverage.append({
                'lockfile': filename, 'added': sorted(new_configs - old_configs),
                'removed': sorted(old_configs - new_configs)
            })
    added_files = sorted(head.keys() - base.keys())
    removed_files = sorted(base.keys() - head.keys())
    content_changed = sorted(name for name in base.keys() & head.keys() if base[name].sha256 != head[name].sha256)
    def inventory(states: dict[str, LockState]) -> list[dict[str, Any]]:
        return [
            {'path': name, 'sha256': state.sha256, 'configurations': sorted(state.configurations),
             'module_configuration_entries': len(state.records)}
            for name, state in sorted(states.items())
        ]
    return {
        'schema_version': 1, 'status': 'comparison_completed',
        'semantic_change': bool(changes or coverage or added_files or removed_files),
        'component_configuration_changes': changes,
        'configuration_coverage_changes': coverage,
        'lockfiles_added': added_files, 'lockfiles_removed': removed_files,
        'lockfiles_content_changed': content_changed,
        'base_inventory': inventory(base), 'head_inventory': inventory(head),
        'limitations': LIMITATIONS
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base', type=Path, required=True, help='Existing base directory snapshot')
    parser.add_argument('--head', type=Path, required=True, help='Existing candidate directory snapshot')
    parser.add_argument('--pattern', action='append', default=[], help='Additional relative glob for a custom modern lockfile; repeatable')
    parser.add_argument('--fail-on-change', action='store_true', help='Exit 1 for semantic differences; this is NOT a security policy')
    args = parser.parse_args(argv)
    try:
        for pattern in args.pattern:
            if PurePosixPath(pattern).is_absolute() or '..' in PurePosixPath(pattern).parts:
                raise InputError('Patterns must be relative and must not contain ..')
        base, base_skipped = load_snapshot(args.base, args.pattern)
        head, head_skipped = load_snapshot(args.head, args.pattern)
        report = compare(base, head)
        report['additional_patterns'] = args.pattern
        report['skipped_symlink_directories'] = {'base': base_skipped, 'head': head_skipped}
        print(json.dumps(report, indent=2, sort_keys=True))
        return 1 if args.fail_on_change and report['semantic_change'] else 0
    except (InputError, OSError, UnicodeError) as error:
        print(json.dumps({'schema_version': 1, 'status': 'invalid_or_missing_evidence', 'error': str(error)}, indent=2))
        return 2


if __name__ == '__main__':
    sys.exit(main())
