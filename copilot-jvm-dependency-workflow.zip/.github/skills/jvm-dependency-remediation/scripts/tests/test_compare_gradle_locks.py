from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SCRIPTS = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(SCRIPTS))
from compare_gradle_locks import InputError, compare, load_snapshot, parse_lock


class LockComparisonTests(unittest.TestCase):
    def diff(self, old: str, new: str):
        return compare({'gradle.lockfile': parse_lock(old)}, {'gradle.lockfile': parse_lock(new)})

    def test_version_change(self):
        result = self.diff('g:a:1=runtimeClasspath\nempty=', 'g:a:2=runtimeClasspath\nempty=')
        self.assertTrue(result['semantic_change'])
        self.assertEqual(result['component_configuration_changes'][0]['after'], '2')

    def test_distinct_versions_by_configuration(self):
        result = self.diff('g:a:1=compileClasspath\ng:a:2=runtimeClasspath\nempty=',
                           'g:a:2=compileClasspath,runtimeClasspath\nempty=')
        self.assertEqual(len(result['component_configuration_changes']), 1)
        self.assertEqual(result['component_configuration_changes'][0]['configuration'], 'compileClasspath')

    def test_added_and_removed(self):
        result = self.diff('g:a:1=runtimeClasspath\nempty=', 'g:b:1=runtimeClasspath\nempty=')
        self.assertEqual({x['kind'] for x in result['component_configuration_changes']}, {'added', 'removed'})

    def test_removed_empty_configuration(self):
        result = self.diff('empty=testRuntimeClasspath', 'empty=')
        self.assertTrue(result['semantic_change'])
        self.assertEqual(result['configuration_coverage_changes'][0]['removed'], ['testRuntimeClasspath'])

    def test_populated_to_empty_preserves_coverage(self):
        result = self.diff('g:a:1=runtimeClasspath\nempty=', 'empty=runtimeClasspath')
        self.assertEqual(result['configuration_coverage_changes'], [])
        self.assertEqual(result['component_configuration_changes'][0]['kind'], 'removed')

    def test_reordering_is_not_semantic_change(self):
        result = self.diff('g:a:1=runtimeClasspath,compileClasspath\nempty=',
                           '# another comment\ng:a:1=compileClasspath,runtimeClasspath\nempty=')
        self.assertFalse(result['semantic_change'])
        self.assertEqual(result['lockfiles_content_changed'], ['gradle.lockfile'])

    def test_conflicting_versions_rejected(self):
        with self.assertRaises(InputError):
            parse_lock('g:a:1=runtimeClasspath\ng:a:2=runtimeClasspath\nempty=')

    def test_empty_and_populated_rejected(self):
        with self.assertRaises(InputError):
            parse_lock('g:a:1=runtimeClasspath\nempty=runtimeClasspath')

    def test_malformed_coordinate_rejected(self):
        with self.assertRaises(InputError):
            parse_lock('not-a-coordinate=runtimeClasspath')

    def test_comments_only_rejected(self):
        with self.assertRaises(InputError):
            parse_lock('# nothing else')

    def test_repeated_configuration_rejected(self):
        with self.assertRaises(InputError):
            parse_lock('g:a:1=runtimeClasspath,runtimeClasspath')

    def test_missing_lockfiles_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(InputError):
                load_snapshot(Path(tmp), [])

    def test_legacy_layout_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp) / 'gradle/dependency-locks'
            folder.mkdir(parents=True)
            (folder / 'runtimeClasspath.lockfile').write_text('g:a:1\n')
            with self.assertRaises(InputError):
                load_snapshot(Path(tmp), [])

    def test_custom_pattern(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'custom.lockfile'
            path.write_text('g:a:1=runtimeClasspath\nempty=')
            states, skipped = load_snapshot(Path(tmp), ['**/custom.lockfile'])
            self.assertIn('custom.lockfile', states)
            self.assertEqual(skipped, [])

    def test_buildscript_and_nested_discovery(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp) / 'service'
            folder.mkdir()
            (folder / 'gradle.lockfile').write_text('g:a:1=runtimeClasspath\nempty=')
            (Path(tmp) / 'buildscript-gradle.lockfile').write_text('g:b:2=classpath\nempty=')
            states, _ = load_snapshot(Path(tmp), [])
            self.assertEqual(len(states), 2)

    @unittest.skipUnless(hasattr(os, 'symlink'), 'symlinks unavailable')
    def test_symlinked_lock_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'target.txt'
            target.write_text('empty=')
            (Path(tmp) / 'gradle.lockfile').symlink_to(target)
            with self.assertRaises(InputError):
                load_snapshot(Path(tmp), [])

    def test_added_lockfile_is_semantic(self):
        state = parse_lock('empty=')
        result = compare({'gradle.lockfile': state}, {'gradle.lockfile': state, 'sub/gradle.lockfile': state})
        self.assertTrue(result['semantic_change'])
        self.assertEqual(result['lockfiles_added'], ['sub/gradle.lockfile'])

    def test_cli_reporting_and_fail_flag(self):
        with tempfile.TemporaryDirectory() as tmp:
            base, head = Path(tmp) / 'base', Path(tmp) / 'head'
            base.mkdir(); head.mkdir()
            (base / 'gradle.lockfile').write_text('g:a:1=runtimeClasspath\nempty=')
            (head / 'gradle.lockfile').write_text('g:a:2=runtimeClasspath\nempty=')
            args = [sys.executable, str(SCRIPTS / 'compare_gradle_locks.py'), '--base', str(base), '--head', str(head)]
            normal = subprocess.run(args, capture_output=True, text=True, check=False)
            strict = subprocess.run(args + ['--fail-on-change'], capture_output=True, text=True, check=False)
            self.assertEqual(normal.returncode, 0)
            self.assertTrue(json.loads(normal.stdout)['semantic_change'])
            self.assertEqual(strict.returncode, 1)

    def test_cli_missing_evidence_returns_two(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = subprocess.run([sys.executable, str(SCRIPTS / 'compare_gradle_locks.py'), '--base', tmp, '--head', tmp],
                                    capture_output=True, text=True, check=False)
            self.assertEqual(result.returncode, 2)
            self.assertEqual(json.loads(result.stdout)['status'], 'invalid_or_missing_evidence')

    def test_hash_matches_raw_bytes(self):
        import hashlib
        with tempfile.TemporaryDirectory() as tmp:
            raw = b'# Windows line endings\r\ng:a:1=runtimeClasspath\r\nempty=\r\n'
            (Path(tmp) / 'gradle.lockfile').write_bytes(raw)
            states, _ = load_snapshot(Path(tmp), [])
            self.assertEqual(states['gradle.lockfile'].sha256, hashlib.sha256(raw).hexdigest())


if __name__ == '__main__':
    unittest.main()
