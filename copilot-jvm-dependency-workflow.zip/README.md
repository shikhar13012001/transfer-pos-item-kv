# Copilot JVM Dependency Remediation Starter

An evidence-first Copilot skill plus three custom agents for Java/Kotlin JVM dependency
resolution and vulnerability remediation. It is designed to accept a dependency list
copied/exported from an enterprise dashboard such as Dot Connector, then independently
verify the repository before proposing or applying any update. Gradle is the primary
path; Maven guidance is included to prevent applying Gradle-specific mechanics to Maven.

## Core behavior

The dashboard list is an **intake queue, not an edit plan**. A row such as:

```text
io.netty:netty-codec-http2 | current 4.x | recommended 4.y | HIGH
```

is never translated directly into `4.x -> 4.y`. The workflow first establishes:

1. whether that version exists in the current revision/artifact;
2. every affected module/configuration and introducing path;
3. whether the component is direct, transitive, build/plugin, shaded, or image content;
4. what actually owns the selected version (declaration, catalog, BOM/platform,
   convention plugin, constraint, substitution, lock, plugin classpath, etc.);
5. whether a candidate is available internally, organization-approved, actually
   remediating, and compatible;
6. what graph/package/test evidence is required to prove the change.

The dashboard-recommended version can be accepted, rejected, or replaced. It is always
`candidate-only` until independently supported.

## Included artifacts

- `.github/skills/jvm-dependency-remediation/SKILL.md`: portable workflow and gates.
- `references/dashboard-intake.md`: normalize and reconcile enterprise dashboard rows.
- `assets/dashboard-intake-template.md`: optional copy/paste input structure.
- `.github/agents/*.agent.md`: VS Code triage, remediator and reviewer profiles.
- `.github/dependency-policy.json`: deliberately unconfigured team-policy template.
- Gradle/Kotlin/gRPC, Maven, validation/review and evaluation references.
- Candidate plan and evidence/PR-body templates.
- `scripts/compare_gradle_locks.py`: supplemental native Gradle lock-state diff.
- `docs/copilot-enterprise-dependency-remediation-prompt.md`: standalone invocation prompt.
- `docs/invocation-examples.md`: staged Copilot usage examples.

No scanner/registry integration, actual repository remediation, internal approval,
CI enforcement, PR publication or deployment is performed merely by installing these
files. No dependency/plugin versions are hardcoded as current or approved.

## Install without overwriting your repository

1. Unzip to a temporary directory and review every file, tool permission and script.
2. Copy `.github/skills/jvm-dependency-remediation/` into your repository.
3. Copy the three `.github/agents/*.agent.md` profiles when using Copilot in VS Code.
4. Merge/fill `.github/dependency-policy.json` through normal team review. Do not
   replace existing repository instructions, CI, CODEOWNERS, or existing policy files.
5. Configure approved evidence/registry sources, module/configuration coverage and
   actual repository commands. Set `configured` only after team review.
6. Start with `jvm-dependency-triage` and paste the dependency list using
   `docs/copilot-enterprise-dependency-remediation-prompt.md` or the shorter examples.

For the standalone `skill.zip`, extract `jvm-dependency-remediation` under
`.github/skills/`. `agents/openai.yaml` is portable skill metadata, not a Copilot
custom-agent profile; the Copilot profiles are the files under `.github/agents/`.

## Workflow

```text
ENTERPRISE DASHBOARD LIST
        |
        v
INTAKE: normalize every row
        |
        v
ANALYZE: reconcile current repository/artifact
        |
        +--> already fixed / stale / absent / blocked -> explicit disposition
        |
        v
COLLECT: approved Gradle graph evidence where needed
        |
        v
GROUP by version owner / compatibility boundary
        |
        v
PLAN_READY: independently selected target set
        |
        v
HUMAN/POLICY APPROVAL
        |
        v
REMEDIATE: change the actual version owner
        |
        v
VALIDATE: graph -> scan -> tests -> package/startup -> required CI
        |
        v
READ-ONLY REVIEW
        |
        v
PR-ready evidence -> normal publication/release process
```

A large dashboard export can be triaged in one run, but unrelated dependencies should
not be remediated in one giant patch. Sensitive runtime families default to one root
update/compatibility boundary per plan unless approved policy says otherwise.

## Why three agents

- `jvm-dependency-triage`: read/search only. Normalizes source rows and plans without
  claiming to run Gradle or change files.
- `jvm-dependency-remediate`: shell/edit capable. Collects actual graph evidence and,
  only after plan approval, implements and validates one compatibility boundary.
- `jvm-dependency-review`: read/search only. Audits the dashboard-to-graph mapping,
  target rationale, complete diff and validation claims.

These are staged roles, not three agents simultaneously modifying the same branch.
A prompt is not a sandbox or an enterprise approval mechanism; keep host execution
controls, least privilege, branch protections and CI enforcement.

## Policy fields to configure

The starter policy deliberately defaults to `configured: false` and explicit plan
approval. Configure at least:

- the approved artifact repositories and version/security approval authorities;
- accepted evidence sources, including the enterprise dashboard/export;
- Gradle modules/configurations that must be inspected;
- actual dependencyInsight/resolve/lock/test/package/scan commands;
- family-specific tests for sensitive stacks such as gRPC/Netty/TLS;
- protected files and low-risk auto-merge allowlist, if any.

Do not treat artifact availability as approval. Do not let the agent edit this policy
to authorize its own proposed version.

## Lock comparison helper

Python 3.10+ and the standard library only. The helper does not invoke Gradle, Git,
network services, or scanners. Supply two existing directory snapshots containing
modern native Gradle lockfiles:

```bash
python .github/skills/jvm-dependency-remediation/scripts/compare_gradle_locks.py \
  --base /path/to/base-snapshot --head /path/to/candidate-snapshot
```

The helper compares selected versions/configurations only. It cannot find parent
paths, unlocked scopes, variants/classifiers, shaded copies, artifact authenticity,
binary compatibility, or vulnerabilities. An empty diff is not a clean security scan.

## Tests

```bash
python -m unittest discover \
  -s .github/skills/jvm-dependency-remediation/scripts/tests -v
```

The acceptance scenarios in `references/evaluation-scenarios.md` are pilot cases for
your repository. Keep high-risk families manual until those scenarios and required CI
show the workflow is reliable in your environment.
