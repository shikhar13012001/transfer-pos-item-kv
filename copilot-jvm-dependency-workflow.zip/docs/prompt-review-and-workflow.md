# Review of the current prompt and proposed JVM workflow

## Assessment

The photographed prompt is a useful remediation checklist. Keep its strongest
requirements: inspect repository instructions, use existing evidence, verify actual
resolved/package contents, prefer approved sources, preserve dependency scopes,
avoid unrelated changes, and never weaken security controls or dismiss alerts just
to reduce counts.

The gap is not a missing request to inspect dependencies; that request already
exists. The gap is an executable contract: discovery scope, version ownership,
inputs/outputs, approval gates, validation coverage, stop conditions, and who may
publish. This starter makes those explicit without assuming access to internal
systems or selecting imaginary approved versions.

## Problems and improvements

| Current pattern | Practical problem | Replacement |
|---|---|---|
| Analyze all currently actionable vulnerabilities and create a focused PR | Potentially unbounded scope conflicts with a focused change | Inventory broadly if requested; remediate one approved compatibility boundary per plan |
| Runtime/test/tooling/transitive listed as alternative categories | Origin and execution scope overlap | Record scope and direct/transitive origin independently for each configuration |
| Stale, duplicate and no longer reachable grouped together | These require different evidence and dispositions | Record scan revision/digest, component presence, duplicate advisory aliases and exploitability separately |
| Internal registry/catalog/Confluence all presented as approved sources | Artifact existence can be mistaken for approval | Separate artifact availability, policy authority, security coverage and compatibility evidence |
| Smallest compatible remediation without a selection algorithm | Agent may choose the smallest text diff or start pinning child libraries | Prefer the owning parent/platform maintenance release, then a coordinated set, then a reviewed constraint |
| Generic repository instructions without a JVM model | Agent can miss compiler/plugin classpaths, JVM targets, included builds or shaded libraries | Add Gradle/Kotlin-specific discovery and conditional family references |
| No explicit plan approval checkpoint | Implementation can begin with guessed or incomplete compatibility assumptions | PLAN_READY with exact candidate, files, base revision, evidence and checks; wait for human approval |
| Branch creation described under delivery | Work can be performed before branch/base/worktree safety is addressed | Establish the approved base and preserve local edits before source changes |
| Regenerate verification metadata along with lockfiles/SBOMs | A generated checksum may bless the bytes just downloaded | Treat verification metadata as a trust decision with provenance review, not ordinary generated output |
| Run all validation plus a clean build | No baseline, targeted test selection, cost sequence or honest missing-test state | Use baseline -> resolution/diff -> scan/targeted tests -> packaged startup -> final required checks |
| Stop or report the blocker | Reporting a blocker can still be followed by an unsafe patch | Fail closed for the blocked candidate while allowing other read-only analysis |
| Commit, push and open PR as automatic delivery | Publication becomes inseparable from diagnosis and local remediation | Return a validated patch and PR-ready body; publication uses separate authorization/automation |

These are workflow-design recommendations, not claims that an observed repository
has already suffered each failure.

## Architecture

Use one portable skill plus small role wrappers, not one enormous always-on prompt:

- Skill: the reusable procedure, Gradle/JVM references, templates and helper.
- Triage agent: read/search only, examines existing evidence and prepares a plan.
- Remediation agent: read/search/edit/execute, collects evidence first, waits for
  plan approval, then edits and validates.
- Review agent: read/search only, checks the full diff and underlying evidence.
- Team policy and CI: establish authority and enforce actual merge/security gates.

The skill does not configure a scanner or registry connection. The supplied policy
JSON is a workflow convention; Copilot does not natively enforce that schema.
Permissions, approved execution, protected branches and required checks remain
outside the language-model prompt.

## Operating workflow

### 1. Preflight and scope

Identify requested advisories/modules, the intended base commit, existing user
changes, available reports, wrapper/JDK/Kotlin plugin, and team policy. Do not
reset/stash user changes or assume `main`, `:app`, Spring Boot or `integrationTest`.

Output: scope, environment, available sources, exact missing evidence.

### 2. Baseline and paths

Use current equivalent CI evidence where available, or collect approved diagnostics
in a trusted workspace. Gradle execution is executable build code, even when the
task only appears to print dependencies. A read-only triage agent cannot run it.

Typical templates (replace placeholders before running):

```bash
./gradlew --version
./gradlew :service:dependencies --configuration runtimeClasspath
./gradlew :service:dependencyInsight --configuration runtimeClasspath --dependency io.netty:netty-handler
./gradlew :service:dependencyInsight --configuration compileClasspath --dependency io.netty:netty-handler
./gradlew :service:buildEnvironment
```

Record every introducing path and selection reason. Extend coverage to affected
test/generator/plugin/included-build configurations. Do not mistake a successful
dependency-report task for proof that all actual artifacts resolve.

Keep the dimensions independent:

```yaml
component: group:artifact
selected_version: observed-version
origin: transitive
scopes: [runtimeClasspath, testRuntimeClasspath]
introducing_paths: [all-observed-paths]
version_owner: observed-parent-or-platform
presence: observed
exploitability: unknown
scan_revision_or_digest: observed-or-unknown
```

Output: reproducible dependency ownership and evidence table.

### 3. Supported target set

Evaluate the owning parent/platform maintenance release first. Then consider a
coordinated update. Use a temporary child constraint only with evidence and an
owner/removal condition. Apply plugin fixes to the build classpath, not application
`implementation`; route OS findings to the approved image process.

Record separately whether the candidate is available internally, approved by the
policy authority, clear of the scoped advisory, and supported by the consuming stack.
An available artifact or a published compatibility table cannot establish all four.

For gRPC/Netty, include every sharing parent, transport choice, Netty/tcnative,
Protobuf runtime/generator, and target runtime. Updating external Netty does not
replace Netty embedded in `grpc-netty-shaded`. For Kotlin, check plugin/toolchain
compatibility and Java/Kotlin JVM targets, not only library versions.

Output: exact candidate set, expected graph diff, alternatives and rationale.

### 4. Approval

Return the plan template and stop. The approval refers to a plan ID, base revision,
exact candidate, allowed file scope, and validation commands. Diagnostic execution
permission and clicking a handoff are not candidate approval.

No internal approval: BLOCKED_APPROVAL. Missing graph/artifact identity:
BLOCKED_EVIDENCE. Continue read-only analysis for other findings where useful.

### 5. Scoped implementation

Work on an approved branch/base, preserving user changes. Edit the owner in the
existing centralized location. Regenerate only relevant lock/generated state with
approved tooling, inspect all changes, and review new verification trust metadata.
Do not introduce new scanners/convergence frameworks or edit CI/policy to unblock
this fix. Ask again when scope/target/base materially changes.

### 6. Pre-deploy validation

Resolve covered configurations/artifacts, inspect graph and coverage deltas, scan
with approved tools, run family-specific behavior tests, then start the packaged
application in a representative runtime. Run repository-mandated checks; avoid
repeated expensive full builds while exploring candidates.

Record command, revision, timestamp, exit code, cache status and log path. Use
PASS, FAIL, NOT_RUN, BLOCKED or justified NOT_APPLICABLE. Unknown is not pass.

Classify failed candidates: artifact availability/auth/network, unsatisfied
constraints, compilation/code generation, runtime linkage/native loading, or
behavioral regression. Do not cycle versions to solve a network outage. Use a
bounded candidate budget, then escalate with failed hypotheses and evidence.

### 7. Read-only review and publication handback

Review the entire resolved change, not the dependency named in the PR. Inspect
raw evidence; an additional agent is not an independent security authority.
Return PR-ready content, risk classification and missing checks. Publication,
merge and deployment remain separately authorized human/CI actions.

Keep the final lower-environment gate focused on behavior not reproduced in CI.
Promote one immutable artifact, monitor rollout, and distinguish patch validation,
merge, scanner refresh, deployment and deployment validation. Accepted risk is not
remediation.

## Pilot before automation

Run the evaluation scenarios in the skill references against representative test
repositories/branches. At minimum cover a direct patch, multi-parent transitive,
shaded dependency, plugin finding, missing internal approval, and missing tests.
Reject a pilot that guesses versions, hides unknown checks, broadens permissions,
or changes an unrelated graph family. Keep runtime-sensitive updates manual until
both agent behavior and required CI have been demonstrated.

## Source and testing scope

The source prompt was reviewed from the two supplied screenshots; no hidden
repository, internal registry or scanner content was inspected. Product syntax and
JVM guidance are based on primary references listed in the skill's sources file.
The helper's unit tests are real executions. The agent workflow has not been run
end to end inside Copilot or against the user's enterprise repository.

---

## Enterprise dashboard-list intake extension

When the operator supplies a dependency list from Dot Connector or another enterprise
SCA dashboard, treat each row as a scanner observation rather than a requested edit.
The current repository's resolved graph and packaged artifact remain the dependency
truth for remediation planning. A dashboard `recommendedVersion` is a candidate only.

Required flow:

```text
Dashboard row
  -> normalize raw evidence
  -> reconcile current revision/artifact
  -> identify all paths/scopes/version owner
  -> independently choose supported target set
  -> form compatibility-boundary plan
  -> explicit approval
  -> implement + validate
  -> map every original row to final disposition
```

This extension prevents four common automation failures: applying a stale dashboard
version to a newer branch; directly pinning a vulnerable transitive instead of its
owning BOM/parent; accepting an internally available but unapproved version; and
claiming a shaded/packaged copy was fixed by changing an unrelated external module.

Use `docs/copilot-enterprise-dependency-remediation-prompt.md` for the complete
copy/paste invocation contract.
