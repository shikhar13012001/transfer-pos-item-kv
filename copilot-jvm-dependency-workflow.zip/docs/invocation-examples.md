# Invocation examples

Select `jvm-dependency-triage` for dashboard intake. In a compatible VS Code agent
session, the skill can also be invoked with `/jvm-dependency-remediation` or by
explicitly asking Copilot to read its SKILL.md. Use the custom agents when you need
the bundled read-only tool boundary; invoking a skill alone does not restrict tools.

## 1. Dashboard list intake and analysis

Use jvm-dependency-remediation in INTAKE then ANALYZE mode for the dependency list
below. Treat every dashboard version and recommended target as evidence only, not an
edit instruction. Reconcile each row with the current Java/Kotlin repository and our
approved dependency policy. Determine actual selected versions, all affected
configurations, direct/transitive paths, version owner, and artifact presence.

Triage the whole list and return:
1. A dashboard-to-repository reconciliation table for every row.
2. Findings already fixed/stale/absent/blocked, with evidence.
3. Compatibility-boundary remediation batches for actionable findings.
4. For each batch, the independently selected supported target set and why it is
   preferable to or consistent with the dashboard recommendation.
5. Exact missing diagnostic/approval evidence and validation requirements.

Do not execute commands, edit files, or publish anything in the triage profile.

Paste dependency list here:
[DEPENDENCY LIST]

## 2. Collect missing reports

Switch to `jvm-dependency-remediate` and use COLLECT mode for one proposed batch.
Run only approved diagnostic/baseline commands in a trusted workspace. Preserve
tracked sources and local work. Capture exact revision, commands, exit status and
log/evidence locations. Refresh the plan with the actual resolved graph, then stop
for candidate approval.

## 3. Approve one plan

I approve plan [PLAN-ID], candidate [ID], against base [COMMIT], limited to
[FILES/COMPONENTS] and its specified validation commands. Implement and validate
that compatibility boundary only. Request renewed approval for a changed target set,
broader scope, new source-code adaptation, or protected-file change. Do not commit,
push, open a PR, merge, deploy, or dismiss alerts.

## 4. Review

Use `jvm-dependency-review`. Review the original dashboard rows, reconciliation,
approved plan, complete dependency diff and raw validation evidence. Identify any
source recommendation that was accepted without independent support, missing
configuration coverage, unexpected graph changes, or weakened controls. Return a
recommendation for the human reviewer without modifying files.
