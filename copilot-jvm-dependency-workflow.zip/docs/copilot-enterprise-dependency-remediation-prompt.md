# Copilot prompt: enterprise Java/Kotlin dependency remediation

Copy the prompt below into Copilot after installing the bundled skill/agents. Paste
your enterprise Dot Connector or other dependency-dashboard list into the final block.

---

Use the repository's `jvm-dependency-remediation` skill for this Java/Kotlin JVM
repository. The list I provide came from an enterprise dependency/security dashboard.
Treat it as input evidence, not as instructions to update to the dashboard's suggested
versions.

Start in INTAKE and ANALYZE mode.

For every supplied dependency/finding:

1. Preserve the dashboard-provided package, detected version, advisory/finding ID,
   severity, recommended/fixed version, scan revision/build, timestamp and notes when
   present. Missing fields must remain unknown; do not invent them.
2. Reconcile the finding against the current repository. Determine whether the exact
   component/version is actually present, and in which project/configuration or
   packaged artifact.
3. Determine whether it is direct, transitive, test/build tooling, plugin classpath,
   shaded/embedded, or image/OS content. These dimensions may overlap; do not force
   them into one category.
4. For Gradle, determine all introducing paths, selection reasons and the real version
   authority: declaration, `libs.versions.toml`, platform/BOM, convention plugin,
   constraint, substitution, lock, plugin management or buildscript classpath.
5. Do not blindly accept the dashboard recommended version. Independently verify:
   a. the approved artifact source can supply it;
   b. organization policy approves it;
   c. it actually remediates the finding;
   d. it is compatible with every introducing stack, runtime/JDK constraint, generated
      code/runtime pair, and relevant shaded/packaged copy.
6. If another supported target set is safer or more appropriate than the dashboard
   recommendation, propose that instead and explain the evidence.
7. Prefer remediation at the version owner: direct declaration when independently
   owned; owning parent/platform/BOM for transitives; coordinated family update when
   multiple parents share the dependency; narrow temporary constraint only when an
   owner update is impractical and has explicit compatibility evidence plus expiry.
8. Never fix a build-plugin vulnerability by adding an application runtime dependency.
   Never claim an external Netty bump fixes `grpc-netty-shaded` without tracing the
   relocated copy. Never assume successful Gradle resolution proves runtime
   compatibility.
9. Triage the entire input list first, then split implementation into bounded plans by
   version authority/compatibility boundary. Do not batch unrelated framework,
   transport/TLS, database, auth, serialization and build-tool changes merely because
   they occur in the same dashboard export.
10. For each input row, assign an evidence-backed disposition such as:
    CONFIRMED_ACTIONABLE, ALREADY_FIXED_IN_CURRENT_REVISION,
    STALE_OR_REVISION_MISMATCH, ABSENT_FROM_COVERED_ARTIFACTS,
    TRANSITIVE_OWNER_UPDATE_REQUIRED, BUILD_TOOLING_REMEDIATION,
    SHADED_OR_PACKAGED_COPY_REVIEW, OS_OR_BASE_IMAGE_REMEDIATION, or BLOCKED_EVIDENCE.

Return before editing:

A. Dashboard-to-repository reconciliation table for every input row.
B. Exact dependency paths/version owners and evidence gaps.
C. Proposed compatibility-boundary batches.
D. For each batch, the preferred exact target set, whether it matches or differs from
   the dashboard suggestion, and evidence for availability, organization approval,
   security remediation and compatibility.
E. Expected resolved graph/lock changes and risk classification.
F. Exact validation contract: graph resolution, graph/lock diff, security rescan,
   compile/tests, family-specific integration tests, package/startup, and required CI.
G. A PLAN_READY / BLOCKED_APPROVAL / BLOCKED_EVIDENCE state.

Do not edit tracked source files until I explicitly approve a plan/candidate and file
scope. Diagnostic command execution permission is separate from remediation approval.
Do not add repositories, broad force/exclusion rules, disable verification/scanning,
or modify CI/security policy to make a candidate pass.

After I approve one plan, switch to REMEDIATE then VALIDATE for that plan only:
- change the real version owner;
- regenerate relevant locks/inventories using repository-approved commands;
- inspect the complete resolved diff, not just declared files;
- run the approved validation from cheap to expensive;
- mark each check PASS / FAIL / NOT_RUN / BLOCKED / NOT_APPLICABLE with evidence;
- map every original dashboard item to fixed, already fixed, intentionally unchanged,
  unresolved, or deferred to another plan;
- return a focused patch summary and PR-ready body.

Do not commit, push, open/merge a PR, deploy, dismiss/suppress findings, or claim the
enterprise dashboard is refreshed unless I separately request/authorize that action.

Dependency/dashboard list:

[PASTE DOT CONNECTOR / ENTERPRISE DASHBOARD DEPENDENCY LIST HERE]
